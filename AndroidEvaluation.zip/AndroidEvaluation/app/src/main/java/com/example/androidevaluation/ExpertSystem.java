package com.example.androidevaluation;

public class ExpertSystem {


    int num_apps, num_mws;
    boolean root, wireless, dev_menu, OS_version, safety_app, pins, encrypted;
    int mw_E,S_E,B_E,evaluation;

    ExpertSystem(int num_apps, int num_mws, boolean root, boolean wireless,
                      boolean dev_menu, boolean OS_version, boolean safety_app, boolean pins, boolean encrypted){
        this.num_apps = num_apps;
        this.num_mws = num_mws;
        this.root =root;
        this.wireless = wireless;
        this.dev_menu = dev_menu;
        this.OS_version = OS_version;
        this.safety_app = safety_app;
        this.encrypted = encrypted;
        this.pins = pins;

        mw_evaluation();
        status_evaluation();
        bonus_evaluation();

        final_evaluation();
    }

    public void mw_evaluation(){
        if(num_mws > 10){
            mw_E= 6;
        }
        else if(num_mws == 0){
            mw_E= 0;
        }
        else  if(num_apps / num_mws < 3){
            mw_E= 6;
        }
        else if(num_apps / num_mws < 5 ){
            mw_E= 4;
        }
        else if (num_apps / num_mws < 10){
            mw_E= 2;
        }
        else mw_E= 1;
    }

    public void status_evaluation(){
        if(root) S_E= 7;
        else if(wireless & dev_menu & OS_version) S_E= 6;
        else if((wireless&dev_menu) | (dev_menu&OS_version) | (wireless&OS_version)) S_E= 4;
        else if(wireless | dev_menu | OS_version) S_E= 2;
        else S_E= 0;
    }

    public void bonus_evaluation(){
        int count = 0;
        if(safety_app) mw_E = mw_E/2;
        if (pins) count--;
        if (encrypted) count--;
        B_E= count;
    }

    public void final_evaluation(){
        evaluation = Math.min(mw_E + S_E + B_E , 10);
    }

}
