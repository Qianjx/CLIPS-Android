package com.example.androidevaluation;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getAllStatus(v);
            }
        });

    }


    public void getAllStatus(View w){
        //collecting all information
        Switch root = (Switch) findViewById(R.id.root);
        boolean rootS = root.isChecked();

        Switch wireless = (Switch) findViewById(R.id.wireless);
        boolean wirelessS = wireless.isChecked();

        Switch OS_version = (Switch) findViewById(R.id.AndroidVersion);
        boolean OS_versionS = OS_version.isChecked();

        Switch Dev_menu = (Switch) findViewById(R.id.developmenu);
        boolean Dev_menuS = Dev_menu.isChecked();

        Switch encrypted = (Switch) findViewById(R.id.encrypted);
        boolean encryptedS = encrypted.isChecked();

        Switch pins = (Switch) findViewById(R.id.pins);
        boolean pinsS = pins.isChecked();

        Switch security_app = (Switch) findViewById(R.id.security_app);
        boolean security_appS = security_app.isChecked();

        TextView num_app = (TextView) findViewById(R.id.num_app);
        int num_appS = Integer.parseInt(num_app.getText().toString());

        TextView num_mw = (TextView) findViewById(R.id.num_mw);
        int num_mwS = Integer.parseInt((String) num_mw.getText().toString());

        //expert system works here
        ExpertSystem ES = new ExpertSystem(num_appS,num_mwS,
                rootS,wirelessS,OS_versionS,Dev_menuS,security_appS,pinsS,encryptedS);


        //Suggestions
        String diagnose = "Result of your phone: " + ES.evaluation + " points\n";
        if (ES.evaluation > 6) diagnose = diagnose + "Your phone is under great risk!\n\n";
        else if (ES.evaluation > 2) diagnose = diagnose + "There're several risks with your phone!\n\n";
        else diagnose = diagnose + "Your phone is quite safe!\n\n";

        if(ES.evaluation != 0){
            diagnose = diagnose + "Suggest Solutions:\n";
            if (ES.mw_E > 3 & !security_appS) diagnose = diagnose + "Too much malwares, install a security app to protect your phone!\n";
            if (rootS) diagnose = diagnose + "Ban root access to protect your phone!\n";
            if (wirelessS) diagnose = diagnose + "You are under an unsafe WLAN, be aware!\n";
            if (OS_versionS) diagnose = diagnose + "Android version out od dated, Get latest Android version!\n";
        }


        //showing a dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("EVALUATION RESULT");
        builder.setMessage(diagnose);
        builder.setPositiveButton("confirm", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //doing nothing
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();

        //TextView result = (TextView) findViewById(R.id.result);
        //result.setText(Integer.toString(ES.evaluation));

    }
    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
    //public native String stringFromJNI();
    //public native void CLIPS();
}
