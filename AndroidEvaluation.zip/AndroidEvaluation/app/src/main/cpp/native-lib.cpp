#include <jni.h>
#include <string>
#include "clips.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_example_androidevaluation_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Hello from C++";
    return env->NewStringUTF(hello.c_str());
}

/*
extern "C" JNIEXPORT void JNICALL
Java_com_example_androidevaluation_MainActivity_CLIPS(JNIEnv * env, jobject){

    void *theEnv;

    theEnv = CreateEnvironment();

    EnvLoad(theEnv, "Android.clp");
    EnvAssertString(theEnv, "(data1 3 100)");
    EnvAssertString(theEnv, "(data2 n y y y)");
    EnvAssertString(theEnv, "(data3 n n y)");
    EnvReset(theEnv);
    EnvRun(theEnv, -1);

    EnvDecrementGCLocks(theEnv);

}
*/